import { Header } from "./components/header";
import { Footer } from "./components/footer";
import { ListVideos } from "./components/listVideos";
import { SearchBar } from "./components/searchBar";
import "./App.css";
import axios from 'axios';
import { useState } from "react";


function App() {

  const endpoint = "http://127.0.0.1:8000/"

  let [videos, setVideos] = useState([])
  let [count, setCount] = useState(0)

  function get(searchText) {
    axios.post(endpoint+"video/",{
      method: 'POST',
      data:{video:searchText},
      mode:'no-cors'
    })
    .then(response => response.data)
    .then(data => {
      if(data.status){
        let new_videos = videos
        new_videos.push(data)
        setVideos(new_videos)
        setCount(++count)
      }
    })
  }

  return (
    <>
    <Header/>
    <div className="view">
      <div className="title-text">
        <h1>YouTube Video &amp; Playlist Downloader</h1>
        <p>
          Paste the link of YouTube video or playlist below and press the button
        </p>
      </div>
      <SearchBar getterFunction={get}/>
      <ListVideos videos={videos}/>
    </div>
    <Footer/>
    </>
  );
}

export default App;
