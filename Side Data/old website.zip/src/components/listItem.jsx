import { Dropdown } from './dropdown';

export function ListItem({video_data}) {

  function getLength() {
    let seconds = video_data.video_data.length
    let hours = Math.floor(seconds/3600)
    seconds = seconds%3600
    let mins = Math.floor(seconds/60)
    seconds = seconds%60
    return(hours+":"+mins+":"+seconds)
  }

  return (
    <div className="item">
      <div className="thumbnail">
        <img
          src={video_data.video_data.thumbnail}
          alt="Thumbnail"
        />
      </div>
      <div className="title">
        <h3>{video_data.video_data.title}</h3>
      </div>
      <div className="length">
        <h4>{getLength()}</h4>
      </div>
      <div className="views">
        <h4>Views: {video_data.video_data.views}</h4>
      </div>
      <div className="date-ago">
        <h4>{
          video_data.video_data.publish_date.publish_day
          +"-"+video_data.video_data.publish_date.publish_month
          +"-"+video_data.video_data.publish_date.publish_year 
          }</h4>
      </div>
      <div className="download">
        <Dropdown formats={video_data.video_data.streams.formats} adaptiveFormats={video_data.video_data.streams.adaptiveFormats}/>
      </div>
    </div>
  );
}
