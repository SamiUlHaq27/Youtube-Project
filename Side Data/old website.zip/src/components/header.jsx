export function Header() {
  return (
    <div className="header">
      <h3>YTPD</h3>
      <ul>
        <li>Home</li>
        <li>Terms Of Use</li>
        <li>Privacy Policy</li>
        <li>About Us</li>
      </ul>
    </div>
  );
}
