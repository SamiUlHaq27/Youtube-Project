export function Dropdown({formats, adaptiveFormats}) {

  function getMime(mime) {
    return(mime.split(";")[0])
  }

  return (
    <div className="download-div">
      <div className="dropdown">
        <div className="dp-title">Download</div>
        <div className="body">
          {
            formats.map((data, i)=>{
              return(
              <a href={data.url}>
                <div className="option">
                  <span>{getMime(data.mimeType)}</span>
                  <span>{data.qualityLabel}</span>
                </div>
              </a>
              )})
          }
          {
            adaptiveFormats.map((data, i)=>{
              return(
              <a href="#">
                <div className="option">
                  <span>{getMime(data.mimeType)} - </span>
                  <span>{data.qualityLabel?data.qualityLabel+" Only Video":"Only Audio"}</span>
                </div>
              </a>
              )})
          }
        </div>
      </div>
    </div>
  );
}
