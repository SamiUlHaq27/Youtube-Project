import '../css/listStyle.css'
import { ListItem } from './listItem'


export function ListVideos({videos}) {
  return (
    <>
    <div className="screen">
      {videos.map((video, i)=>{
        return(<ListItem video_data={video} key={i}/>)
      })}
    </div>
    <div className="buttons-tools">
      <button>Download All</button>
      <button>Copy Youtube Links</button>
      <button>Copy Source Links</button>
    </div>
    </>
  );
}
