export function Footer() {
  return (
    <div className="footer">
      <h3>YTPD</h3>
      <p>Copyright by YTPD</p>
    </div>
  );
}
