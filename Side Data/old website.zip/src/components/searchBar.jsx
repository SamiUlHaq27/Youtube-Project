import Icon from '../images/download.png'
import {useState} from 'react'


export function SearchBar({getterFunction}) {
    const [search_text, setsearch_text] = useState("")

    function getSearch(event) {
        setsearch_text(event.target.value);
    }
  return (
    <div className="search-bar">
      <form action="" method="get">
        <input type="text" placeholder="Paste link here" name="searchText" onChange={getSearch} value={search_text}/>
        <div className="icon-wrap" onClick={()=>getterFunction(search_text)}>
          <img src={Icon} alt="Go"/>
        </div>
      </form>
    </div>
  );
}
